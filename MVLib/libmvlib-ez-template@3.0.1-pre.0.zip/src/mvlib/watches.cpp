#include "mvlib/watches.hpp"
#include "mvlib/core.hpp"
#include "mvlib/private/terminalOut.hpp"
#include "mvlib/private/sdCsv.hpp"
#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdlib>

namespace mvlib {
Logger::InternalWatch* Logger::m_findWatchUnlocked(WatchId id) {
  auto it = std::find_if(m_watches.begin(), m_watches.end(),
                         [id](const InternalWatch& watch) { return watch.id == id; });
  return (it == m_watches.end()) ? nullptr : &(*it);
}

const Logger::InternalWatch* Logger::m_findWatchUnlocked(WatchId id) const {
  auto it = std::find_if(m_watches.begin(), m_watches.end(),
                         [id](const InternalWatch& watch) { return watch.id == id; });
  return (it == m_watches.end()) ? nullptr : &(*it);
}

std::optional<std::string> Logger::m_getWatchNameUnlocked(WatchId id, bool isElevated) const {
  const InternalWatch* watch = m_findWatchUnlocked(id);
  if (!watch) return std::nullopt;

  if (isElevated && !watch->elevatedLabel.empty()) return watch->elevatedLabel;
  else return watch->label;
}

void Logger::resyncAllWatchesRoster() {
  detail::uniqueLock lock(m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked()) return;
  if (m_watches.empty()) return;
  if (!ensureTerminalSession()) return;

  sendAllWatchRostersLocked();
  m_lastRosterFlush.store(pros::millis());
}

bool Logger::resyncWatchRoster(WatchId id) {
  detail::uniqueLock lock(m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked()) return false;
  if (m_watches.empty()) return false;

  InternalWatch* watch = m_findWatchUnlocked(id);
  if (!watch || !watch->active) return false;
  if (!ensureTerminalSession()) return false;

  sendWatchRosterLocked(*watch);
  m_lastRosterFlush.store(pros::millis());
  return true;
}

void Logger::sendWatchRosterLocked(const InternalWatch& watch) {
  detail::Telemetry::getInstance().sendRoster(watch.id, watch.label, false);
  if (!watch.elevatedLabel.empty()) {
    detail::Telemetry::getInstance().sendRoster(watch.id,
                                                 watch.elevatedLabel, true);
  }
}

void Logger::sendAllWatchRostersLocked() {
  for (const auto& watch : m_watches) {
    sendWatchRosterLocked(watch);
  }
}

std::string Logger::evaluateWatch(WatchId id, bool emit) {
  LogLevel lvl{};
  std::string valueStr{};
  std::string label{};
  bool tripped = false;
  uint32_t nowMs = 0;
  std::shared_ptr<std::function<std::tuple<LogLevel, std::string, std::string, bool>()>> eval;
  std::shared_ptr<pros::Mutex> evalMutex;

  {
    // Manual watch evaluation intentionally invokes the stored evaluator directly
    // so stateful watch closures keep their internal transition/debounce state.
    detail::uniqueLock lock(m_mutex, TIMEOUT_MAX);
    if (!lock.isLocked()) return {};
    if (m_watches.empty()) return {};

    InternalWatch* watch = m_findWatchUnlocked(id);
    if (!watch || !watch->eval || !watch->evalMutex) return {};
    eval = watch->eval;
    evalMutex = watch->evalMutex;
  }

  detail::uniqueLock callbackLock(*evalMutex, TIMEOUT_MAX);
  if (!callbackLock.isLocked()) return {};

  std::tie(lvl, valueStr, label, tripped) = (*eval)();
  if (!emit) return valueStr;

  nowMs = pros::millis();

  if (ensureTerminalSession()) {
    bool sentAsBinary = false;

    if (!valueStr.empty()) {
      char* end = nullptr;
      errno = 0;
      const float numericVal = std::strtof(valueStr.c_str(), &end);
      if (end != valueStr.c_str() && end != nullptr && *end == '\0' &&
          errno != ERANGE && std::isfinite(numericVal)) {
        detail::Telemetry::getInstance().sendWatch(id, lvl, numericVal, tripped);
        sentAsBinary = true;
      }
    }

    if (!sentAsBinary) {
      detail::Telemetry::getInstance().sendWatchText(id, lvl, valueStr, tripped);
    }
  }

  if (m_config.logToSD.load()) {
    if (valueStr == "f") valueStr = "false";
    if (valueStr == "t") valueStr = "true";

    logToSD(lvl, "[WATCH],%u,%s,%u,%s,%s", nowMs,
            levelToString(lvl), id, detail::escapeSdCsvField(label).c_str(),
            detail::escapeSdCsvField(valueStr).c_str());
  }

  return valueStr;
}

void Logger::configureDefaultWatch(WatchId id, uint32_t trippedRepeatIntervalMs) {
  detail::uniqueLock lock(m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked()) return;

  InternalWatch* watch = m_findWatchUnlocked(id);
  if (!watch) return;

  watch->suppressNormalOutput = true;
  watch->trippedRepeatIntervalMs = trippedRepeatIntervalMs;
}
} // namespace mvlib
