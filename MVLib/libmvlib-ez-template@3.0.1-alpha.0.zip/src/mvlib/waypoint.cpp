#include "mvlib/core.hpp"
#include "mvlib/private/terminalOut.hpp"
#include "mvlib/waypoint.hpp"
#include "mvlib/private/raii.hpp"
#include "mvlib/private/sdCsv.hpp"
#include <limits>
#include <cmath>
#include <cstdio>
#include <string>
#include <algorithm>

namespace mvlib {
namespace {
std::string formatParams(const WaypointParams& params) {
  char buf[256];
  snprintf(buf, sizeof(buf), "%.2f,%.2f,%s,%s,%.2f,%s,%d",
           params.tarX, params.tarY,
           params.tarT.has_value() ? std::to_string(params.tarT.value()).c_str() : "NA",
           params.timeoutMs.has_value() ? std::to_string(params.timeoutMs.value()).c_str() : "NA",
           params.linearTol,
           params.thetaTol.has_value() ? std::to_string(params.thetaTol.value()).c_str() : "NA",
           params.retriggerable ? 1 : 0);
  return std::string(buf);
}
} // namespace

Logger::InternalWaypoint* Logger::m_findWaypointUnlocked(WPId id) {
  auto it = std::find_if(m_waypoints.begin(), m_waypoints.end(),
                         [id](const InternalWaypoint& waypoint) { return waypoint.id == id; });
  return (it == m_waypoints.end()) ? nullptr : &(*it);
}

const Logger::InternalWaypoint* Logger::m_findWaypointUnlocked(WPId id) const {
  auto it = std::find_if(m_waypoints.begin(), m_waypoints.end(),
                         [id](const InternalWaypoint& waypoint) { return waypoint.id == id; });
  return (it == m_waypoints.end()) ? nullptr : &(*it);
}

WaypointOffset Logger::getWaypointOffset(WPId id) {
  WaypointParams params{};
  uint32_t startTimeMs = 0;
  bool waypointReached = false;
  bool waypointTimedOut = false;
  std::shared_ptr<std::function<std::optional<Pose>()>> poseGetter;
  std::shared_ptr<pros::Mutex> poseGetterMutex;

  {
    detail::uniqueLock lock(m_mutex);
    if (!lock.isLocked()) return {};

    const InternalWaypoint* waypoint = m_findWaypointUnlocked(id);
    if (!waypoint) return {};
    params = waypoint->params;
    startTimeMs = waypoint->startTimeMs;
    waypointReached = waypoint->reached;
    waypointTimedOut = waypoint->timedOut;
    poseGetter = m_getPose;
    poseGetterMutex = m_poseGetterMutex;
  }

  WaypointOffset offset{};
  offset.reached = waypointReached;
  // Timeout state is owned by printWaypoints(); this accessor only reports it.
  if (params.timeoutMs.has_value()) {
    uint32_t elapsed = pros::millis() - startTimeMs;
    const bool expired = elapsed >= params.timeoutMs.value();
    offset.remainingTimeout = expired ? 0 : params.timeoutMs.value() - elapsed;
    offset.timedOut = waypointTimedOut;
  } else {
    offset.remainingTimeout = std::nullopt;
    offset.timedOut = false;
  }

  std::optional<Pose> pose = std::nullopt;
  if (poseGetter && poseGetterMutex) {
    detail::uniqueLock callbackLock(*poseGetterMutex, TIMEOUT_MAX);
    if (callbackLock.isLocked()) {
      pose = (*poseGetter)();
    }
  }
  if (!pose) return offset;

  // Linear Offsets
  offset.offX = params.tarX - pose->x;
  offset.offY = params.tarY - pose->y;
  offset.totalOffset = sqrt(offset.offX * offset.offX + offset.offY * offset.offY);

  // Angular Offset (Wrapped to [-180, 180])
  if (params.tarT.has_value()) {
    double error = params.tarT.value() - pose->theta;
    error = fmod(error + 180.0, 360.0);
    if (error < 0) error += 360.0;
    offset.offT = error - 180.0;
  }

  return offset;
}

WaypointHandle Logger::internalRegisterWaypoint(std::string name, WaypointParams details) {
  detail::uniqueLock lock(m_mutex);
  if (!lock.isLocked()) return WaypointHandle(0);
  if (!m_config.logToTerminal.load() && !m_config.logToSD.load()) return WaypointHandle(0);

  WPId id = m_nextId++;
  InternalWaypoint wp;
  wp.id = id;
  wp.name = std::move(name);
  wp.startTimeMs = pros::millis();
  wp.active = true;
  wp.timedOut = false;
  wp.createdWithOutputEnabled = m_config.printWaypoints.load();

  if (details.tarT.has_value() && !details.thetaTol.has_value())
    details.thetaTol = details.linearTol;

  if (!details.tarT.has_value() && details.thetaTol.has_value())
    details.thetaTol = std::nullopt;

  wp.params = details;

  m_waypoints.push_back(std::move(wp));

  if (!m_waypoints.back().createdWithOutputEnabled) return WaypointHandle(id);

  if (ensureTerminalSession()) {
    sendWaypointMetadataLocked(m_waypoints.back());
  }

  if (m_config.logToSD.load()) logWaypointCreatedToSD(m_waypoints.back());
  return WaypointHandle(id);
}

void Logger::logWaypointCreatedToSD(const InternalWaypoint& waypoint) {
  logToSD(LogLevel::OVERRIDE, "[WPOINT],%u,CREATED,%u,%s,%s",
          waypoint.startTimeMs, waypoint.id, detail::escapeSdCsvField(waypoint.name).c_str(),
          formatParams(waypoint.params).c_str());
}

void Logger::sendWaypointMetadataLocked(const InternalWaypoint& waypoint) {
  detail::Telemetry::getInstance().sendRoster(waypoint.id, waypoint.name);

  detail::WaypointCreatedPacket pkt;
  pkt.timestamp = static_cast<uint16_t>(pros::millis());
  pkt.id = waypoint.id;
  pkt.tarX = static_cast<float>(waypoint.params.tarX);
  pkt.tarY = static_cast<float>(waypoint.params.tarY);
  pkt.tarT = detail::packTelemetryTheta(waypoint.params.tarT.value_or(0.0));
  pkt.linTol = waypoint.params.linearTol;
  pkt.thetaTol = waypoint.params.thetaTol.value_or(
      std::numeric_limits<float>::quiet_NaN());
  pkt.timeout = waypoint.params.timeoutMs.value_or(0);
  pkt.retriggerable = waypoint.params.retriggerable ? 1 : 0;
  detail::Telemetry::getInstance().sendWaypointCreated(pkt);
}

std::optional<std::string> Logger::m_getRosterNameUnlocked(uint16_t id, bool isElevated) const {
  if (const InternalWaypoint* waypoint = m_findWaypointUnlocked(id)) return waypoint->name;
  return m_getWatchNameUnlocked(id, isElevated);
}

bool Logger::resyncWaypointRoster(WPId id) {
  detail::uniqueLock lock(m_mutex);
  if (!lock.isLocked()) return false;
  if (m_waypoints.empty()) return false;

  InternalWaypoint* waypoint = m_findWaypointUnlocked(id);
  if (!waypoint || !waypoint->active) return false;
  if (!ensureTerminalSession()) return false;

  sendWaypointMetadataLocked(*waypoint);
  m_lastRosterFlush.store(pros::millis());
  return true;
}

void Logger::resyncAllWaypointsRoster() {
  detail::uniqueLock lock(m_mutex);
  if (!lock.isLocked()) return;
  if (m_waypoints.empty()) return;
  if (!ensureTerminalSession()) return;

  sendActiveWaypointMetadataLocked();
  m_lastRosterFlush.store(pros::millis());
}

void Logger::sendActiveWaypointMetadataLocked() {
  for (const auto& wp : m_waypoints) {
    if (!wp.active) continue;
    sendWaypointMetadataLocked(wp);
  }
}
} // namespace mvlib
