#include "mvlib/waypoint.hpp"
#include "mvlib/core.hpp"
#include "mvlib/private/raii.hpp"

namespace mvlib {
bool WaypointHandle::valid() const {
  return m_id != 0;
}

WaypointOffset WaypointHandle::getOffset() const {
  return Logger::getInstance().getWaypointOffset(this->m_id);
}

WaypointParams WaypointHandle::getParams() const {
  Logger& logger = Logger::getInstance();
  detail::uniqueLock lock(logger.m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked() || logger.m_waypoints.empty()) return {};

  const Logger::InternalWaypoint* waypoint = logger.m_findWaypointUnlocked(this->m_id);
  return waypoint ? waypoint->params : WaypointParams{};
}

bool WaypointHandle::reached() const {
  return Logger::getInstance().getWaypointOffset(this->m_id).reached;
}

std::string WaypointHandle::getLabel() const {
  Logger& logger = Logger::getInstance();
  detail::uniqueLock lock(logger.m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked() || logger.m_waypoints.empty()) return {};

  const Logger::InternalWaypoint* waypoint = logger.m_findWaypointUnlocked(this->m_id);
  return waypoint ? waypoint->name : std::string{};
}

bool WaypointHandle::timedOut() const {
  return Logger::getInstance().getWaypointOffset(this->m_id).timedOut;
}

bool WaypointHandle::active() const {
  Logger& logger = Logger::getInstance();
  detail::uniqueLock lock(logger.m_mutex, TIMEOUT_MAX);
  if (!lock.isLocked() || logger.m_waypoints.empty()) return false;

  const Logger::InternalWaypoint* waypoint = logger.m_findWaypointUnlocked(this->m_id);
  return waypoint ? waypoint->active : false;
}

bool WaypointHandle::resyncRoster() const {
  return Logger::getInstance().resyncWaypointRoster(this->m_id);
}
} // namespace mvlib
